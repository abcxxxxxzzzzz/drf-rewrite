#!/usr/bin/env bash
# 2020-3-13 10:22:30
# Author: ^~^
# Auto Install Nginx Soft
 
#Define Nginx path variables
NGINX_URL=http://nginx.org/download
NGINX_FILE=nginx-1.16.1.tar.gz
NGINX_FILE_DIR=nginx-1.16.1
NGINX_PREFIX=/usr/local/nginx
 

#Install Nginx Soft
if [ ! -d ${NGINX_PREFIX} ];then
	#Install Package
	yum -y install pcre pcre-devel openssl openssl-devel gcc gcc-c++ wget
	wget -c ${NGINX_URL}/${NGINX_FILE}
	tar zxf ${NGINX_FILE}
	cd ${NGINX_FILE_DIR}
	sed -i 's/1.16.1/ /;s/nginx\//nginx/' src/core/nginx.h
	useradd -s /sbin/nologin www
	./configure --prefix=${NGINX_PREFIX} \
	--user=www \
	--group=www \
	--with-http_ssl_module \
        --with-http_v2_module \
	--with-http_stub_status_module
	if [ $? -eq 0 ];then
		make && make install
		echo -e "\033[32mThe Nginx Install Success...\033[0m"
	else
		echo -e "\033[31mThe Nginx Install Failed...\033[0m"
		exit 1
	fi
else
	echo -e "\033[31mThe Nginx already Install...\033[0m"
	exit 1
fi
 
#Config Nginx
ln -sf ${NGINX_PREFIX}/sbin/nginx /usr/sbin
cat >${NGINX_PREFIX}/conf/nginx.conf <<EOF
	user www www;
	worker_processes auto;
	pid /usr/local/nginx/logs/nginx.pid;
events {
	use epoll;
	worker_connections 10240;
	multi_accept on;
	}
http	{
	include       mime.types;
	default_type  application/octet-stream;
	log_format  main  '\$remote_addr - \$remote_user [\$time_local] "\$request" '
                      '\$status \$body_bytes_sent "\$http_referer" '
                      '"\$http_user_agent" "\$http_x_forwarded_for"';
	access_log logs/access.log main;
	error_log logs/error.log warn;
	sendfile        on;
	tcp_nopush          on;
	keepalive_timeout  120;
	tcp_nodelay         on;
	server_tokens off;
	gzip    on;
	gzip_min_length 1k;
	gzip_buffers    4 64k;
	gzip_http_version 1.1;
	gzip_comp_level 4;
	gzip_types      text/plain application/x-javascript text/css application/xml;
	gzip_vary       on;
	client_max_body_size 10m;
	client_body_buffer_size 128k;
	proxy_connect_timeout 90;
	proxy_send_timeout 90;
	proxy_buffer_size 4k;
	proxy_buffers 4 32k;
	proxy_busy_buffers_size 64k;
	large_client_header_buffers 4 4k;
	client_header_buffer_size 4k;
	open_file_cache_valid 30s;
	open_file_cache_min_uses 1;


	upstream backend {
	  server localhost:8080 max_fails=3;
	}

	# 管理后台地址
    server {
        listen       12345;
        server_name  admin.abcxz.xyz;
        root         html;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;
        add_header 'Access-Control-Allow-Origin' '*';
        add_header 'Access-Control-Allow-Credentials' 'true';
        add_header 'Access-Control-Allow-Methods' 'GET';


        location ^~/api/{
          proxy_pass   http://backend;
        }

        error_page 404 /404.html;
        location = /404.html {
        }

        error_page 500 502 503 504 /50x.html;
        location = /50x.html {
        }
    }


    # 对外提供地址
    server {
        #listen       8443 ssl http2;
        listen       8443;
        server_name  abcxz.xyz;


        #ssl_certificate     server.crt;
        #ssl_certificate_key  server.key;

        location /{
          proxy_pass   http://backend;
          proxy_set_header HOST   \$host;
          proxy_set_header X-Real-IP      \$remote_addr;
          proxy_set_header X-Forwarded-FOR \$proxy_add_x_forwarded_for;
          proxy_intercept_errors on;
        }

        location ^~/api {
          allow 127.0.0.1;
          deny all;
        }

        error_page 404 /404.html;
        location = /404.html {
          root       html;
        }
                  
        location ~*\.(png|css)$ {
          root      html;
        }

        error_page 500 502 503 504 /50x.html;
        location = /50x.html {
        }
    }
}
EOF
 
#Start Nginx
${NGINX_PREFIX}/sbin/nginx -t
if [ $? -eq 0 ];then
	${NGINX_PREFIX}/sbin/nginx
fi
 
#Add power on self start
grep -qw "${NGINX_PREFIX}" /etc/rc.d/rc.local
if [ $? -ne 0 ];then
	echo "${NGINX_PREFIX}/sbin/nginx" >>/etc/rc.d/rc.local
	chmod +x /etc/rc.d/rc.local
fi



# Add html
PWD=$(cd `dirname $0`;pwd)
cd $PWD && tar fx html.tar.gz -C ${NGINX_PREFIX}/html/
