geneva.plugins.dns
============================

.. automodule:: plugins.dns.client
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: plugins.dns.server
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: plugins.dns.plugin
   :members:
   :undoc-members:
   :show-inheritance:
