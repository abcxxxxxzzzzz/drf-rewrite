geneva.plugins.plugin
=====================

.. automodule:: plugin
   :members:
   :undoc-members:
   :show-inheritance:
