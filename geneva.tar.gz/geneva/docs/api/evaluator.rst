geneva.evaluator
=================

.. automodule:: evaluator
   :members:
   :undoc-members:
   :show-inheritance:
