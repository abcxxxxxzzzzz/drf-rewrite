geneva.actions.trigger
======================

.. automodule:: trigger
   :members:
   :undoc-members:
   :show-inheritance:
