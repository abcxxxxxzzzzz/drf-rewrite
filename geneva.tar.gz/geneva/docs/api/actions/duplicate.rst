geneva.actions.duplicate 
========================

.. automodule:: duplicate
   :members:
   :undoc-members:
   :show-inheritance:
