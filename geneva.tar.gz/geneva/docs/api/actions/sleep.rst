geneva.actions.sleep
====================

.. automodule:: sleep
   :members:
   :undoc-members:
   :show-inheritance:
