geneva.actions.action
=====================

.. automodule:: action
   :members:
   :undoc-members:
   :show-inheritance:
